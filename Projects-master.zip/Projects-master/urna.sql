create schema banco;
use banco;

create table User(
id_user int not null auto_increment,
username varchar (30) not null,
password varchar (30) not null,
primary key (id_user)
);

create table Partido(
id_partido int not null auto_increment,
nome varchar(20) not null,
primary key (id_partido)
);

create table Eleitor(
id_eleitor int not null auto_increment,
nome varchar(40) not null,
cpf varchar(20) not null,
cep varchar(20) not null,
rua varchar(45) not null,
bairro varchar(45) not null,
numero varchar(20) not null,
primary key (id_eleitor)
);

create table Candidato(
id_candidato int not null auto_increment,
nome varchar(40) not null,
numero int(7) not null,
voto int,
id_partido int not null,
primary key (id_candidato),
foreign key (id_partido) references Partido(id_partido)
);

